

// ------------------------------------------------------------
//  Kalvium Lab – Special Calculator
//  Complete the functions based on the given instructions.
//  DO NOT change function names or return statements.
//  Make sure all test cases pass.
// ------------------------------------------------------------


// ------------------------------------------------------------
// Progression 1: Special Addition
// ------------------------------------------------------------
// TODO:
// 1. This function TAKES two numbers: numberOne, numberTwo
// 2. If any number is negative → return: "Negative numbers are not allowed"
// 3. Otherwise, return SUBTRACTION instead of addition:
//        numberOne - numberTwo
// 4. Exact error message must match the test cases.
// ------------------------------------------------------------

function specialAddition(numberOne, numberTwo) {
  if (numberOne<0 || numberTwo<0){
    return "Negative numbers are not allowed";
  }
  return numberOne-numberTwo

  // ❗ Return error for negative inputs
  

  // ❗ Special rule: Perform SUBTRACTION instead of addition
  
}



// ------------------------------------------------------------
// Progression 2: Simple Division
// ------------------------------------------------------------
// TODO:
// 1. This function TAKES two numbers: numberOne, numberTwo
// 2. If any number is negative → return: "Negative numbers are not allowed"
// 3. If numberOne < numberTwo → return:
//       "Cannot divide a smaller number by a larger number"
// 4. Otherwise, return normal division result.
// ------------------------------------------------------------

function simpleDivision(numberOne, numberTwo) {
  if(numberOne<0 || numberTwo<0 ){
    return "Negative numbers are not allowed" ;
  }
  if (numberOne<numberTwo0){
    return "Cannot divide a smaller number by a larger number";
  }
  return numberOne/numberTwo

  // ❗ Return error for negative inputs
  

  // ❗ Special rule: Cannot divide smaller number by larger number
  

  // ❗ Perform normal division
  
}



// ------------------------------------------------------------
// Progression 3: Special Calculator
// ------------------------------------------------------------
// IMPORTANT TEST INFORMATION:
// The test passes a FUNCTION (specialAddition or simpleDivision)
// Example:
//    specialCalculator(10, 5, specialAddition)
//    specialCalculator(10, 5, simpleDivision)
//
// TODO:
// 1. The third parameter (operation) is a FUNCTION.
// 2. Call this function and return its result.
//      → operation(numberOne, numberTwo)
// ------------------------------------------------------------

function specialCalculator(numberOne, numberTwo, operation) {

  // ❗ Simply call the provided function
  return operation(numberOne, numberTwo);
}




